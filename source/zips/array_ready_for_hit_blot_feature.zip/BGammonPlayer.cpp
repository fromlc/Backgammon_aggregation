//------------------------------------------------------------------------------
// CS 281-0798
// 
// BGammonPlayer.cpp
//
// BGammonPlayer class definition file
//------------------------------------------------------------------------------
#include "BGammonPlayer.h"

#include <string>

//------------------------------------------------------------------------------
// default constructor
//------------------------------------------------------------------------------
BGammonPlayer::BGammonPlayer() : BGammonPlayer("player", "black") {}

//------------------------------------------------------------------------------
// overload constructor
//------------------------------------------------------------------------------
BGammonPlayer::BGammonPlayer(const std::string name, 
                                    const std::string color)
{
    this->name  = name;
    this->color = color;

    this->pieceCount = PIECES_PLAYING;
    this->numMoves = 0;
    this->gamesWon = 0;

    // #TODO find a better way to init array
    for (int i = 0; i < PIECES_PLAYING; i++)
    {
        this->aPiecePositions[i] = 1;
    }
}

//------------------------------------------------------------------------------
// destructor
//------------------------------------------------------------------------------
BGammonPlayer::~BGammonPlayer() {}

//------------------------------------------------------------------------------
// resetPlayer() : resets piece positions to point 1
//------------------------------------------------------------------------------
void BGammonPlayer::resetPlayerBoard()
{
    for (int i = 0; i < PIECES_PLAYING; i++)
        this->aPiecePositions[i] = 1;

    this->pieceCount = PIECES_PLAYING;
    this->numMoves = 0;
}

//------------------------------------------------------------------------------
// pieceCount(): returns # of pieces
// no params: returns # of pieces on board, including on the bar
// int param: returns # of pieces on specified point (1-20)
//------------------------------------------------------------------------------
int BGammonPlayer::getPieceCount(int point)
{
    // no argument passed
    if (point == 0)
        return this->pieceCount; 

    int count = 0;

    // check arg-specified point number for pieces
    for (int i = 0; i < PIECES_PLAYING; i++)
    {
        if (aPiecePositions[i] == point)
            count++;
    }

    return count;

}

//------------------------------------------------------------------------------
// rollDice() : get a new 2-dice roll for player
//------------------------------------------------------------------------------
void BGammonPlayer::rollDice(int& d1, int& d2) 
{
    d1 = this->die1.rollDie();
    d2 = this->die2.rollDie();
}

//------------------------------------------------------------------------------
// viewDice() : look at player's last 2-dice roll
//------------------------------------------------------------------------------
void BGammonPlayer::viewDice(int& d1, int& d2)
{
    d1 = this->die1.getValue();
    d2 = this->die2.getValue();
}

//------------------------------------------------------------------------------
// makeBestMove() : returns new point for moved piece
//------------------------------------------------------------------------------
void BGammonPlayer::makeBestMove(int movePoints, BGammonPlayer& opponent)
{
    // pieces start at point 1
    int farthest = 0, index = 0;
 
    // find the piece farthest along the board
    for (int i = 0; i < PIECES_PLAYING; i++)
    {
        int pos = aPiecePositions[i];
        if (pos > farthest && !opponent.getPieceCount(pos + movePoints))
        {
            farthest = pos;
            index = i;
        }
    }

    // re-find and move the farthest piece along the board
    for (int i = 0; i < PIECES_PLAYING; i++)
    {
        if (this->aPiecePositions[i] == farthest)
        {
            this->aPiecePositions[i] += movePoints;
            this->numMoves++;

            // check for piece borne off
            if (this->aPiecePositions[i] > 20)
            {
                this->aPiecePositions[i] = 0;
                this->pieceCount--;
            }

            // only move one piece
            break;
        }
    }
}


