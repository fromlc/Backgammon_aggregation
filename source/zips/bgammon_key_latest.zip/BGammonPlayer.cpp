//------------------------------------------------------------------------------
// CS 281-0798
// 
// BGammonPlayer.cpp
//
// BGammonPlayer class definition file
//------------------------------------------------------------------------------
#include "BGammonPlayer.h"

#include <algorithm>      // std::fill() array init
#include <iostream>
#include <string>

//------------------------------------------------------------------------------
// default constructor
//------------------------------------------------------------------------------
BGammonPlayer::BGammonPlayer() : BGammonPlayer("BGplayer", "clear") {}

//------------------------------------------------------------------------------
// overload constructor
//------------------------------------------------------------------------------
BGammonPlayer::BGammonPlayer(const std::string name, const std::string color)
{
    this->name  = name;
    this->color = color;

    this->pieceCount = PIECES_PLAYING;
    this->numMoves = 0;     // per die
    this->numRolls = 0;     // per roll of 2 dice
    this->gamesWon = 0;

    // initialize array
    std::fill(aPiecePositions, aPiecePositions + PIECES_PLAYING, START_POINT);
}

//------------------------------------------------------------------------------
// destructor
//------------------------------------------------------------------------------
BGammonPlayer::~BGammonPlayer() {}

//------------------------------------------------------------------------------
// getName()
//------------------------------------------------------------------------------
std::string BGammonPlayer::getName() const { return this->name; }

//------------------------------------------------------------------------------
// getColor()
//------------------------------------------------------------------------------
std::string BGammonPlayer::getColor() const { return this->color; }

//------------------------------------------------------------------------------
// getNumMoves()
//------------------------------------------------------------------------------
int BGammonPlayer::getNumMoves() const
{
    return this->numMoves;
}

//------------------------------------------------------------------------------
// getNumRolls()
//------------------------------------------------------------------------------
int BGammonPlayer::getNumRolls() const { return this->numRolls; }

//------------------------------------------------------------------------------
// getGamesWon()
//------------------------------------------------------------------------------
int BGammonPlayer::getGamesWon() const { return this->gamesWon; }

//------------------------------------------------------------------------------
// getPiecePositions() : return copy of piece positions as array
//      - requires caller memory: POS_TYPE aPos[PIECES_PLAYING]
//      - this fill-in function sets caller's array values
//      = use POS_TYPE for position element type
// 
//------------------------------------------------------------------------------
void BGammonPlayer::getPiecePositions(POS_TYPE aPos[]) const
{
    for (POS_TYPE x = 0; x < PIECES_PLAYING; x++)
    {
        aPos[x] = this->aPiecePositions[x];
    }
}

//------------------------------------------------------------------------------
// pieceCount(): returns # of pieces
// no params: returns # of pieces on board, including on the bar
// int param: returns # of pieces on specified point (1-20)
//------------------------------------------------------------------------------
int BGammonPlayer::getPieceCount(int point)
{
    // no argument passed
    if (point == 0)
        return this->pieceCount; 

    int count = 0;

    // check arg-specified point number for pieces
    for (int i = 0; i < PIECES_PLAYING; i++)
    {
        if (aPiecePositions[i] == point)
            count++;
    }

    return count;

}

//------------------------------------------------------------------------------
// getOppoPieceCount(): returns # of pieces on point
//      - call in context of opponent BGammonPlayer 
//      = returns # of pieces on specified point (1-20)
//------------------------------------------------------------------------------
int BGammonPlayer::getOppoPieceCount(int point)
{
    int count = getPieceCount(point);

    if (count)
    {
        std::cout << "\nOpponent piece(s) on " << point << " point: "
            << count << '\n';
    }
    return count;
}

//------------------------------------------------------------------------------
// resetPlayer() : resets piece positions to point 1
//------------------------------------------------------------------------------
void BGammonPlayer::resetPlayerBoard()
{
    std::fill(aPiecePositions, aPiecePositions + PIECES_PLAYING, START_POINT);

    this->pieceCount = PIECES_PLAYING;
    this->numMoves = 0;
    this->numRolls = 0;
}

//------------------------------------------------------------------------------
// rollDice() : get a new 2-dice roll for player
//------------------------------------------------------------------------------
void BGammonPlayer::rollDice(int& d1, int& d2) 
{
    d1 = this->die1.rollDie();
    d2 = this->die2.rollDie();
    numRolls++;
}

//------------------------------------------------------------------------------
// viewDice() : look at player's last 2-dice roll
//------------------------------------------------------------------------------
void BGammonPlayer::viewDice(int& d1, int& d2)
{
    d1 = this->die1.getValue();
    d2 = this->die2.getValue();
}

//------------------------------------------------------------------------------
// makeBestMove() : returns new point for moved piece
//      - chooses piece farthest along board
//      = cannot move to point occupied by opponent's pieces
//------------------------------------------------------------------------------
void BGammonPlayer::makeBestMove(int movePoints, BGammonPlayer& opponent)
{
    // pieces start at point 1
    int farthest = 0, index = 0;
 
    // find the piece farthest along the board
    for (int i = 0; i < PIECES_PLAYING; i++)
    {
        int pos = aPiecePositions[i];
        // cannot move to point occupied by opponent's piece(s)
        if (pos > farthest && !opponent.getOppoPieceCount(pos + movePoints))
        {
            farthest = pos;
            index = i;
        }
    }

    // check for no pieces to move, or no legal moves
    if (farthest)
    {
        // move the farthest piece along the board
        this->aPiecePositions[index] += movePoints;
        this->numMoves++;
    
        // check for piece borne off
        if (this->aPiecePositions[index] > 20)
        {
            this->aPiecePositions[index] = 0;
            this->pieceCount--;
    
            if (!this->pieceCount)
                this->gamesWon++;
        }
    }
}


