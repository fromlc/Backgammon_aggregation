//------------------------------------------------------------------------------
// td_test.cpp
// CS 281-0798, Fall 2021
//
// Auto Backgammon app
//		- uses class definition BGammonPlayer.cpp
//		= set number of player pieces in BGammonPlayer.h
//------------------------------------------------------------------------------

#include <algorithm>	// std::fill() array init
#include <iostream>
#include <string>
#include <iomanip>

#include "BGammonPlayer.h"

//------------------------------------------------------------------------------
// constants
//------------------------------------------------------------------------------
constexpr int POINT_NUMBER_WIDTH = 3;		// for piece position display

//------------------------------------------------------------------------------
// struct BGammonBoard : aggregates two BGammonPlayer instances
//------------------------------------------------------------------------------
struct BGammonBoard
{
	// players with their previous and current piece positions
	BGammonPlayer player1 = BGammonPlayer("Red", "Red");
	POS_TYPE aPositions1[PIECES_PLAYING] = { START_POINT };
	
	BGammonPlayer player2 = BGammonPlayer("White", "White");
	POS_TYPE aPositions2[PIECES_PLAYING] = { START_POINT };
	
	int gameNum   = 0;
	int playerNum = 0;

	std::string banner = "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";
};

//------------------------------------------------------------------------------
// global variables
//------------------------------------------------------------------------------

// board with 2 players
BGammonBoard g_bb;

//------------------------------------------------------------------------------
// local function prototypes
//------------------------------------------------------------------------------

inline void showBanner();
inline void initBoard();
inline bool winningMove();
bool move(BGammonPlayer& player, BGammonPlayer& opponent);
void showMove(BGammonPlayer& player, int showDie1, int showDie2);
void showPiecePositions(BGammonPlayer& player);
inline void showPos(POS_TYPE* pPos);
bool allPiecesBorneOff(BGammonPlayer& player, BGammonPlayer& opponent);
bool playAgain();

//------------------------------------------------------------------------------
// main() : entry point
//------------------------------------------------------------------------------
int main()
{
	showBanner();

	// one board per do
	do
	{
		initBoard();

		// function returns true on player win
		do { } while (!winningMove());

	} while (playAgain());

	system("pause");

	return 0;
}

//------------------------------------------------------------------------------
// showBanner()
//------------------------------------------------------------------------------
inline void showBanner()
{
	std::string color1 = g_bb.player1.getColor();
	std::string color2 = g_bb.player2.getColor();

	std::cout << g_bb.banner << '\n';
	std::cout << "\t" << "Auto " << color1 << " & " << color2
		<< " Simple Backgammon\n\n";
    std::cout << "\t" << "All pieces start on the " << START_POINT
		<< "-point\n";
    std::cout << "\t" << "and bear off from the " << END_POINT
		<< "- point.\n\n";
    std::cout << "\t" << "The smaller die value moves first.\n";
    std::cout << "\t" << "The piece farthest along is moved.\n\n";
    std::cout << "\t" << "Each 0-point is a piece borne off.\n\n";
	std::cout << "\t" << PIECES_PLAYING << " men per player, "
		<< g_bb.player1.getName() << " moves first.\n\n";
	std::cout << g_bb.banner << '\n';
}

//------------------------------------------------------------------------------
// initBoard()
//------------------------------------------------------------------------------
inline void initBoard()
{
	g_bb.player1.resetPlayerBoard();
	g_bb.player2.resetPlayerBoard();

	// initialize previous/current piece position arrays
	std::fill(g_bb.aPositions1, g_bb.aPositions1 + PIECES_PLAYING, START_POINT);
	std::fill(g_bb.aPositions2, g_bb.aPositions2 + PIECES_PLAYING, START_POINT);

	// output uses 0 for player1, 1 for player2 to
	// select previous positions array for display
	g_bb.playerNum = 0;
}

//------------------------------------------------------------------------------
// winningMove() : returns true if a player won after moving, false otherwise
//------------------------------------------------------------------------------
inline bool winningMove()
{
	bool moveWon = move(g_bb.player1, g_bb.player2);

	if (!moveWon)
	{
		moveWon = move(g_bb.player2, g_bb.player1);
	}

	std::cout << '\n';
	return moveWon;
}

//------------------------------------------------------------------------------
// move() : returns true if player wins after moving, false otherwise
// 
// get 2 die values and move one piece for each
//------------------------------------------------------------------------------
bool move(BGammonPlayer& player, BGammonPlayer& opponent)
{
	int die1, die2;

	// fill-in function sets 2 die values
	player.rollDice(die1, die2);

	// branchless way to choose the bigger value
	int bigDie = die1 * (die1 >= die2) + die2 * (die2 > die1);
	int lilDie = die1 + die2 - bigDie;

	// move a piece for each of the 2 die values, smaller value first
	player.makeBestMove(lilDie, opponent);
	player.makeBestMove(bigDie, opponent);

	// display smaller die value first
	showMove(player, lilDie, bigDie);

	// check for all pieces borne off
	return allPiecesBorneOff(player, opponent);
}

//------------------------------------------------------------------------------
// showMove()
// 
// show player name and dice values for roll
//------------------------------------------------------------------------------
void showMove(BGammonPlayer& player, int showDie1, int showDie2)
{
	// static var retains value between calls to this function
	static int playerNum, gameNum;

	// in case previous game won by player 1 
	if (gameNum != g_bb.gameNum)
	{
		gameNum = g_bb.gameNum;
		playerNum = 0;
	}

	// display only before player1 positions
	if (!(playerNum++ % 2))
		std::cout << "  Roll " << player.getNumRolls() << '\n';

	// display smaller die value first
	std::cout << '\t' << player.getName() << '\t'
		<< showDie1 << ' ' << showDie2 << ": ";
	
	showPiecePositions(player);
}

//------------------------------------------------------------------------------
// showPiecePositions()
// 
// show player piece positions after move
//------------------------------------------------------------------------------
void showPiecePositions(BGammonPlayer& player)
{
	// determine which player and point to their previous positions
	POS_TYPE* pPos = g_bb.playerNum++ % 2 ? g_bb.aPositions2 : g_bb.aPositions1;

	// show this player's previous position
	showPos(pPos);
	std::cout << "  ->";

	// fill in copy of player's current piece positions
	player.getPiecePositions(pPos);

	// show this player's current position
	showPos(pPos);
	std::cout << '\n';
}

//------------------------------------------------------------------------------
// showPos() : utility function shows previous or current point positions
//------------------------------------------------------------------------------
inline void showPos(POS_TYPE* pPos)
{
	std::cout.right;

	for (POS_TYPE x = 0; x < PIECES_PLAYING; x++)
	{
		std::cout << std::setw(POINT_NUMBER_WIDTH) << pPos[x];
	}
}

//------------------------------------------------------------------------------
// allPiecesBorneOff() : returns true if player won
//------------------------------------------------------------------------------
bool allPiecesBorneOff(BGammonPlayer& player, BGammonPlayer& opponent)
{
	// zero pieces left on board => player won
	if (!player.getPieceCount())
	{
		std::string name = player.getName();

		// display stats
		std::cout << '\n' << name << " wins in "
			<< player.getNumRolls() << " rolls!\n";
		std::cout << "\nBoards won: " << name << ' ' << player.getGamesWon()
			<< ", " << opponent.getName() << ' ' << opponent.getGamesWon()
			<< '\n';

		// increment game counter for correct display
		g_bb.gameNum++;

		return true;
	}

	return false;
}

//------------------------------------------------------------------------------
// playAgain()
//
// returns true if user wants to play again, false otherwise
//------------------------------------------------------------------------------
bool playAgain()
{
	char answer;
	//Get user input
	do
	{
		std::cout << "Play another board? (Y/N): ";
		std::cin >> answer;
	}
	while (!std::cin);

	return toupper(answer) == 'Y' ? true : false;
}

