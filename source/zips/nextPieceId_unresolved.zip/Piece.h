//------------------------------------------------------------------------------
// CS 281-0798
// 
// Piece class declaration/definition file
//------------------------------------------------------------------------------
#pragma once
#ifndef PIECE_H
#define PIECE_H

#include <string>

//------------------------------------------------------------------------------
// Piece : position and id for each piece in BGammonPlayer
//------------------------------------------------------------------------------
class Piece
{
private:
    static int nextPieceId;  // initialized outside class below

public:
    std::string color;
    int onPoint;  // pieces occupy points 0-21: 0 is bar, >=21 is borne off
    int id;

    // default constructor
    Piece() : Piece("black") {}

    // overload constructor
    Piece(const std::string& color)
    {
        this->color   = color;
        this->onPoint = 1;
        this->id = nextPieceId++;
    }

    // copy constructor
    Piece(const Piece& pieceOnRight)
    {
        this->color   = pieceOnRight.color;
        this->onPoint = pieceOnRight.onPoint;
        // make Piece id unique
        this->id = nextPieceId++;
        //this->id = pieceOnRight.id;
    }

    // destructor
    ~Piece() { nextPieceId--; }

    // operator > overload compares onPoint values
    bool operator>(Piece& pieceOnRight)
    { return (this->onPoint > pieceOnRight.onPoint); }

    // zero the Piece id tracker
    static void resetNextPieceId()
    { nextPieceId = 0; }

};

//------------------------------------------------------------------------------
// instantiate and initialize class static data
//------------------------------------------------------------------------------
int Piece::nextPieceId = 0;

#endif  // PIECE_H

