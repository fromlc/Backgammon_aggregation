/*******************************************************************************
* td_test.cpp
* Matthew Rasmusson
* CS 281-0798, Fall 2021
* November 8, 2021
*
* Write a console app that utilizes a class instances and a header file to track rolling dice
*********************************************************************************/

#include <iostream>
#include <string>
#include <iomanip>
#include <vector>

#include "BGammonPlayer.h"
#include "TumblingDie.h"

//------------------------------------------------------------------------------
// local function prototypes
//------------------------------------------------------------------------------

void displayBanner();
bool playAgain();
bool move(BGammonPlayer& player, BGammonPlayer& opponent);

//------------------------------------------------------------------------------
// struct BGammonBoard : aggregates two BGammonPlayer instances
//------------------------------------------------------------------------------
struct BGammonBoard
{
	BGammonPlayer playBlack = BGammonPlayer("Black", "black");
	BGammonPlayer playWhite = BGammonPlayer("White", "white");
};

//------------------------------------------------------------------------------
// main() : entry point
//------------------------------------------------------------------------------
int main()
{
	displayBanner();

	// #TODO init class Piece static data
	Piece trix;
	trix.resetNextPieceId();
	
	// 	one board per do
	do
	{
		BGammonBoard bb;
		bool winner = false;

		do
		{
			if (!move(bb.playBlack, bb.playWhite))
				winner = move(bb.playWhite, bb.playBlack);
			else
				winner = true;

			std::cout << '\n';

		} while (!winner);

	} while (playAgain());

	system("pause");

	return 0;
}

//------------------------------------------------------------------------------
// displayBanner()
//------------------------------------------------------------------------------
void displayBanner()
{
    std::cout << "Auto Backgammon with 3 Men\n";
    std::cout << "__________________________\n\n";
}

//------------------------------------------------------------------------------
// playAgain()
//
// returns true if user wants to play again, false otherwise
//------------------------------------------------------------------------------
bool playAgain()
{
	char answer;
	//Get user input
	do
	{
		std::cout << "\n\nPlay another game? (Y/N): ";
		std::cin >> answer;
	}
	while (!std::cin);

	return toupper(answer) == 'Y' ? true : false;
}

//------------------------------------------------------------------------------
// move() : returns true if player wins after moving, false otherwise
// 
// get 2 die values and move one piece for each
//------------------------------------------------------------------------------
bool move(BGammonPlayer& player, BGammonPlayer& opponent)
{
	int die1, die2;

	// fill-in function gets 2 die values
	player.rollDice(die1, die2);
	std::cout << player.name << " rolls " 
		<< die1 << ' ' << die2 << ": ";

	// branchless way to choose the bigger value
	int bigDie = die1 * (die1 >= die2) + die2 * (die2 > die1);
	int lilDie = die1 + die2 - bigDie;

	// move a piece for each of the 2 die values, smaller value first
	Piece movedPiece;
	player.makeBestMove(lilDie, opponent, movedPiece);
	player.makeBestMove(bigDie, opponent, movedPiece);

	// display piece positions for this player after moves
	for (auto ev : player.getPiecePositions())
	{
		std::cout << ev.onPoint << ' ';
	}
	std::cout << '\n';

	// check for all pieces borne off
	if (!player.getPieceCount())
	{
		std::cout << '\n' << player.name << " wins!\n\n";
		return true;
	}

	return false;
}