//------------------------------------------------------------------------------
// CS 281-0798
// 
// BGammonPlayer.cpp
//
// BGammonPlayer class definition file
//------------------------------------------------------------------------------
#include "BGammonPlayer.h"

#include <string>
#include <vector>

//------------------------------------------------------------------------------
// default constructor
//------------------------------------------------------------------------------
BGammonPlayer::BGammonPlayer() : BGammonPlayer("player", "black") {}

//------------------------------------------------------------------------------
// overload constructor
//------------------------------------------------------------------------------
BGammonPlayer::BGammonPlayer(const std::string name, 
                                    const std::string color)
{
    this->name = name;
    this->color = color;

    this->pieceCount = PIECES_PLAYING;
    this->gamesWon = 0;

    Piece temp;

    for (int i = 0; i < PIECES_PLAYING; i++)
        vPieces.push_back(temp);
}

//------------------------------------------------------------------------------
// destructor
//------------------------------------------------------------------------------
BGammonPlayer::~BGammonPlayer() {}

//------------------------------------------------------------------------------
// getPiecePositions() : returns copy of pieces position array
//------------------------------------------------------------------------------
std::vector<Piece> BGammonPlayer::getPiecePositions()
{ return this->vPieces; }

//------------------------------------------------------------------------------
// pieceCount(): returns # of pieces
// no params: returns # of pieces on board, including on the bar
// int param: returns # of pieces on specified point (1-20)
//------------------------------------------------------------------------------
int BGammonPlayer::getPieceCount(int point)
{
    // no argument passed
    if (point == 0)
        return this->pieceCount; 

    int count = 0;

    // check arg-specified point number for pieces
    for (auto ve : vPieces)
    {
        if (ve.onPoint == point)
        {
            count++;
        }
    }

    return count;

}

//------------------------------------------------------------------------------
// rollDice() : get a new 2-dice roll for player
//------------------------------------------------------------------------------
void BGammonPlayer::rollDice(int& d1, int& d2) 
{
    d1 = this->die1.rollDie();
    d2 = this->die2.rollDie();
}

//------------------------------------------------------------------------------
// viewDice() : look at player's last 2-dice roll
//------------------------------------------------------------------------------
void BGammonPlayer::viewDice(int& d1, int& d2)
{
    d1 = this->die1.getValue();
    d2 = this->die2.getValue();
}

//------------------------------------------------------------------------------
// makeBestMove() : fills in moved Piece info
//------------------------------------------------------------------------------
void BGammonPlayer::makeBestMove(int movePoints, BGammonPlayer& opponent, Piece& farthest)
{
    // find man closest to bearing off
    farthest.onPoint = 0;
 
    // find the piece farthest along the board
    Piece* pMmoveIt = nullptr;
    int index = 0;
    for (Piece& ve : vPieces)
    {
        if (ve > farthest && !opponent.getPieceCount(ve.onPoint + movePoints))
        {
            farthest = ve;
            break;
        }
        index++;
    }

    // add move's position
    vPieces.at(index).onPoint += movePoints;
    // check for piece borne off
    if (vPieces.at(index).onPoint > 20)
    {
        vPieces.at(index).onPoint = 0;
        pieceCount--;
    }

    // complete Piece data fill-in
    farthest.onPoint = vPieces.at(index).onPoint;
}


