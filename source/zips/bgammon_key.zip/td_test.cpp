//------------------------------------------------------------------------------
// td_test.cpp
// CS 281-0798, Fall 2021
//
// Auto Backgammon app
//		- uses class definition BGammonPlayer.cpp
//		= set number of player pieces in BGammonPlayer.h
//------------------------------------------------------------------------------

#include <iostream>
#include <string>
#include <iomanip>

#include "BGammonPlayer.h"

//------------------------------------------------------------------------------
// struct BGammonBoard : aggregates two BGammonPlayer instances
//------------------------------------------------------------------------------
struct BGammonBoard
{
	BGammonPlayer player1 = BGammonPlayer("Red", "Red");
	BGammonPlayer player2 = BGammonPlayer("White", "White");
	int gameNum = 0;
};

//------------------------------------------------------------------------------
// global variables
//------------------------------------------------------------------------------
BGammonBoard g_bb;

//------------------------------------------------------------------------------
// local function prototypes
//------------------------------------------------------------------------------

inline void showBanner();
inline void initBoard();
inline bool winningMove();
bool move(BGammonPlayer& player, BGammonPlayer& opponent);
void showMove(BGammonPlayer& player, int showDie1, int showDie2);
void showPiecePositions(BGammonPlayer& player);
bool allPiecesBorneOff(BGammonPlayer& player, BGammonPlayer& opponent);
bool playAgain();

//------------------------------------------------------------------------------
// main() : entry point
//------------------------------------------------------------------------------
int main()
{
	showBanner();

	// 	one board per do
	do
	{
		initBoard();

		// function returns true on player win
		do { } while (!winningMove());

	} while (playAgain());

	system("pause");

	return 0;
}

//------------------------------------------------------------------------------
// showBanner()
//------------------------------------------------------------------------------
inline void showBanner()
{
	std::string color1 = g_bb.player1.color;
	std::string color2 = g_bb.player2.color;

	std::cout << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";
	std::cout << "  Auto " << color1 << " & " << color2
		<< " Backgammon\n\n";
    std::cout << "  " << "All pieces start on the 1-point\n";
    std::cout << "  " << "and bear off from the 20-point.\n\n";
    std::cout << "  " << "The smaller die value moves first.\n\n";
    std::cout << "  " << "Each 0-point is a piece borne off.\n\n";
	std::cout << "  " << PIECES_PLAYING << " men per player, "
		<< g_bb.player1.name << " moves first.\n";
    std::cout << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n\n";
}

//------------------------------------------------------------------------------
// initBoard()
//------------------------------------------------------------------------------
inline void initBoard()
{
	g_bb.player1.resetPlayerBoard();
	g_bb.player2.resetPlayerBoard();
}

//------------------------------------------------------------------------------
// winningMove() : returns true if a player won after moving, false otherwise
//------------------------------------------------------------------------------
inline bool winningMove()
{
	bool moveWon = move(g_bb.player1, g_bb.player2);

	if (!moveWon)
	{
		moveWon = move(g_bb.player2, g_bb.player1);
	}

	std::cout << '\n';
	return moveWon;
}

//------------------------------------------------------------------------------
// move() : returns true if player wins after moving, false otherwise
// 
// get 2 die values and move one piece for each
//------------------------------------------------------------------------------
bool move(BGammonPlayer& player, BGammonPlayer& opponent)
{
	int die1, die2;

	// fill-in function sets 2 die values
	player.rollDice(die1, die2);

	// branchless way to choose the bigger value
	int bigDie = die1 * (die1 >= die2) + die2 * (die2 > die1);
	int lilDie = die1 + die2 - bigDie;

	// move a piece for each of the 2 die values, smaller value first
	player.makeBestMove(lilDie, opponent);
	player.makeBestMove(bigDie, opponent);

	// display smaller die value first
	showMove(player, lilDie, bigDie);

	// check for all pieces borne off
	return allPiecesBorneOff(player, opponent);
}

//------------------------------------------------------------------------------
// showMove()
// 
// show player name and dice values for roll
//------------------------------------------------------------------------------
void showMove(BGammonPlayer& player, int showDie1, int showDie2)
{
	// static var retains value between calls to this function
	static int playerNum, gameNum;

	// in case previous game won by player 1 
	if (gameNum != g_bb.gameNum)
	{
		gameNum = g_bb.gameNum;
		playerNum = 0;
	}

	// display only before player1 positions
	if (!(playerNum++ % 2))
		std::cout << "  Roll " << player.numRolls << '\n';

	// display smaller die value first
	std::cout << '\t' << player.name << '\t'
		<< showDie1 << ' ' << showDie2 << ": ";
	
	showPiecePositions(player);
}

//------------------------------------------------------------------------------
// showPiecePositions()
// 
// show player piece positions after move
//------------------------------------------------------------------------------
void showPiecePositions(BGammonPlayer& player)
{
	std::cout << '\t';
	for (int i = 0; i < PIECES_PLAYING; i++)
	{
		std::cout << player.aPiecePositions[i] << ' ';
	}
	std::cout << '\n';
}

//------------------------------------------------------------------------------
// allPiecesBorneOff() : returns true if player won
//------------------------------------------------------------------------------
bool allPiecesBorneOff(BGammonPlayer& player, BGammonPlayer& opponent)
{
	// zero pieces left on board => player won
	if (!player.getPieceCount())
	{
		// display stats
		std::cout << '\n' << player.name << " wins in "
			<< player.numRolls << " rolls!\n";
		std::cout << "\nBoards won: " << player.name << ' ' << player.gamesWon
			<< ", " << opponent.name << ' ' << opponent.gamesWon
			<< '\n';

		// increment game counter for correct display
		g_bb.gameNum++;

		return true;
	}

	return false;
}

//------------------------------------------------------------------------------
// playAgain()
//
// returns true if user wants to play again, false otherwise
//------------------------------------------------------------------------------
bool playAgain()
{
	char answer;
	//Get user input
	do
	{
		std::cout << "Play another board? (Y/N): ";
		std::cin >> answer;
	}
	while (!std::cin);

	return toupper(answer) == 'Y' ? true : false;
}

