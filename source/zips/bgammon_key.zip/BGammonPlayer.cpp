//------------------------------------------------------------------------------
// CS 281-0798
// 
// BGammonPlayer.cpp
//
// BGammonPlayer class definition file
//------------------------------------------------------------------------------
#include "BGammonPlayer.h"

//#include <cstring>      // memset() array init
#include <iostream>
#include <string>

//------------------------------------------------------------------------------
// default constructor
//------------------------------------------------------------------------------
BGammonPlayer::BGammonPlayer() : BGammonPlayer("BGplayer", "clear") {}

//------------------------------------------------------------------------------
// overload constructor
//------------------------------------------------------------------------------
BGammonPlayer::BGammonPlayer(const std::string name, 
                                    const std::string color)
{
    this->name  = name;
    this->color = color;

    this->pieceCount = PIECES_PLAYING;
    this->numRolls = 0;     // per roll of 2 dice
    this->numMoves = 0;     // per die
    this->gamesWon = 0;

    // #TODO find a better way to init array
    //size_t bytes = PIECES_PLAYING * sizeof(this->aPiecePositions[0]);
    // nope. memset() fills memory with unsigned char value 01 here
    //memset(this->aPiecePositions, START_POINT, bytes);
    
    for (int i = 0; i < PIECES_PLAYING; i++)
    {
        this->aPiecePositions[i] = 1;
    }
}

//------------------------------------------------------------------------------
// destructor
//------------------------------------------------------------------------------
BGammonPlayer::~BGammonPlayer() {}

//------------------------------------------------------------------------------
// resetPlayer() : resets piece positions to point 1
//------------------------------------------------------------------------------
void BGammonPlayer::resetPlayerBoard()
{
    for (int i = 0; i < PIECES_PLAYING; i++)
        this->aPiecePositions[i] = 1;

    this->pieceCount = PIECES_PLAYING;
    this->numMoves = 0;
    this->numRolls = 0;
}

//------------------------------------------------------------------------------
// pieceCount(): returns # of pieces
// no params: returns # of pieces on board, including on the bar
// int param: returns # of pieces on specified point (1-20)
//------------------------------------------------------------------------------
int BGammonPlayer::getPieceCount(int point)
{
    // no argument passed
    if (point == 0)
        return this->pieceCount; 

    int count = 0;

    // check arg-specified point number for pieces
    for (int i = 0; i < PIECES_PLAYING; i++)
    {
        if (aPiecePositions[i] == point)
            count++;
    }

    return count;

}

//------------------------------------------------------------------------------
// getOppoPieceCount(): returns # of pieces on point
//      - call in context of opponent BGammonPlayer 
//      = returns # of pieces on specified point (1-20)
//------------------------------------------------------------------------------
int BGammonPlayer::getOppoPieceCount(int point)
{
    int count = getPieceCount(point);

    if (count)
    {
        std::cout << "\nOpponent piece(s) on " << point << " point: "
            << count << '\n';
    }
    return count;
}

//------------------------------------------------------------------------------
// rollDice() : get a new 2-dice roll for player
//------------------------------------------------------------------------------
void BGammonPlayer::rollDice(int& d1, int& d2) 
{
    d1 = this->die1.rollDie();
    d2 = this->die2.rollDie();
    numRolls++;
}

//------------------------------------------------------------------------------
// viewDice() : look at player's last 2-dice roll
//------------------------------------------------------------------------------
void BGammonPlayer::viewDice(int& d1, int& d2)
{
    d1 = this->die1.getValue();
    d2 = this->die2.getValue();
}

//------------------------------------------------------------------------------
// makeBestMove() : returns new point for moved piece
//      - chooses piece farthest along board
//      = cannot move to point occupied by opponent's pieces
//------------------------------------------------------------------------------
void BGammonPlayer::makeBestMove(int movePoints, BGammonPlayer& opponent)
{
    // pieces start at point 1
    int farthest = 0, index = 0;
 
    // find the piece farthest along the board
    for (int i = 0; i < PIECES_PLAYING; i++)
    {
        int pos = aPiecePositions[i];
        // cannot move to point occupied by opponent's piece(s)
        if (pos > farthest && !opponent.getOppoPieceCount(pos + movePoints))
        {
            farthest = pos;
            index = i;
        }
    }

    // check for no pieces to move, or no legal moves
    if (farthest)
    {
        // move the farthest piece along the board
        this->aPiecePositions[index] += movePoints;
        this->numMoves++;
    
        // check for piece borne off
        if (this->aPiecePositions[index] > 20)
        {
            this->aPiecePositions[index] = 0;
            this->pieceCount--;
    
            if (!this->pieceCount)
                this->gamesWon++;
        }
    }
}


