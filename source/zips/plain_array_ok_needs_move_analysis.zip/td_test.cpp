/*******************************************************************************
* td_test.cpp
* Matthew Rasmusson
* CS 281-0798, Fall 2021
* November 8, 2021
*
* Write a console app that utilizes a class instances and a header file to track rolling dice
*********************************************************************************/

#include <iostream>
#include <string>
#include <iomanip>

#include "BGammonPlayer.h"
#include "TumblingDie.h"

//------------------------------------------------------------------------------
// struct BGammonBoard : aggregates two BGammonPlayer instances
//------------------------------------------------------------------------------
struct BGammonBoard
{
	BGammonPlayer playBlack = BGammonPlayer("Black", "black");
	BGammonPlayer playWhite = BGammonPlayer("White", "white");
};

//------------------------------------------------------------------------------
// global variables
//------------------------------------------------------------------------------
BGammonBoard g_bb;

//------------------------------------------------------------------------------
// local function prototypes
//------------------------------------------------------------------------------

void displayBanner();
bool playAgain();
bool move(BGammonPlayer& player, BGammonPlayer& opponent);

//------------------------------------------------------------------------------
// main() : entry point
//------------------------------------------------------------------------------
int main()
{
	displayBanner();

	// 	one board per do
	do
	{
		g_bb.playBlack.resetPlayerBoard();
		g_bb.playWhite.resetPlayerBoard();
		bool winner = false;

		do
		{
			if (!move(g_bb.playBlack, g_bb.playWhite))
				winner = move(g_bb.playWhite, g_bb.playBlack);
			else
				winner = true;

			std::cout << '\n';

		} while (!winner);

	} while (playAgain());

	system("pause");

	return 0;
}

//------------------------------------------------------------------------------
// displayBanner()
//------------------------------------------------------------------------------
void displayBanner()
{
	std::cout << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";
	std::cout << "  Auto Black & White Backgammon\n";
    std::cout << "  " << PIECES_PLAYING << " men per player, "
		<< g_bb.playBlack.name << " moves first \n";
    std::cout << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n\n";
}

//------------------------------------------------------------------------------
// playAgain()
//
// returns true if user wants to play again, false otherwise
//------------------------------------------------------------------------------
bool playAgain()
{
	char answer;
	//Get user input
	do
	{
		std::cout << "Play another board? (Y/N): ";
		std::cin >> answer;
	}
	while (!std::cin);

	return toupper(answer) == 'Y' ? true : false;
}

//------------------------------------------------------------------------------
// move() : returns true if player wins after moving, false otherwise
// 
// get 2 die values and move one piece for each
//------------------------------------------------------------------------------
bool move(BGammonPlayer& player, BGammonPlayer& opponent)
{
	int die1, die2;

	// fill-in function gets 2 die values
	player.rollDice(die1, die2);
	std::cout << player.name << " rolls " 
		<< die1 << ' ' << die2 << ": ";

	// branchless way to choose the bigger value
	int bigDie = die1 * (die1 >= die2) + die2 * (die2 > die1);
	int lilDie = die1 + die2 - bigDie;

	// move a piece for each of the 2 die values, smaller value first
	player.makeBestMove(lilDie, opponent);
	player.makeBestMove(bigDie, opponent);

	// display piece positions for this player after moves
	for (int i = 0; i < PIECES_PLAYING; i++)
	{
		std::cout << player.aPiecePositions[i] << ' ';
	}
	std::cout << '\n';

	// check for all pieces borne off
	if (!player.getPieceCount())
	{
		// display number of moves / 2 = number of rolls
		player.gamesWon++;
		std::cout << '\n' << player.name << " wins in "
			<< player.numMoves / 2 << " rolls!\n";
		std::cout << "\nBoards won: " << player.name << ' ' << player.gamesWon
			<< ", " << opponent.name << ' ' << opponent.gamesWon
			<< '\n';

		return true;
	}

	return false;
}