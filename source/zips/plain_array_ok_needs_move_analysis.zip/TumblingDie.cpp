//------------------------------------------------------------------------------
// CS 281-0798
// 
// TumblingDie.cpp : class definition file
//------------------------------------------------------------------------------
#include "TumblingDie.h"

#include <cstdlib>
#include <ctime>
#include <vector>

//------------------------------------------------------------------------------
// TumblingDie(): default constructor of TumblingDie Class
//------------------------------------------------------------------------------
TumblingDie::TumblingDie() : TumblingDie(DIE_SIDES) {}

//------------------------------------------------------------------------------
// TumblingDie(int sides): initial setter of DieSides with passed int argument
//------------------------------------------------------------------------------
TumblingDie::TumblingDie(int sides)
{ 
    this->sides = sides;
    this->value = 0;
    srand(static_cast<unsigned int>(time(0)));
}

//------------------------------------------------------------------------------
// ~TumblingDie(): Destructor of Vector vRolls
//------------------------------------------------------------------------------
TumblingDie::~TumblingDie()
{
    vRolls.clear();
    vRolls.shrink_to_fit();
}

//------------------------------------------------------------------------------
// getDieSides() : returns the value DieSides
//------------------------------------------------------------------------------
int TumblingDie::getDieSides() const
{ return sides; }

//------------------------------------------------------------------------------
// setDieSides() : returns the value DieSides
//------------------------------------------------------------------------------
void TumblingDie::setDieSides(int sides)
{ this->sides = sides; }

//------------------------------------------------------------------------------
// getRollHistory() : returns a copy of the vector vRolls
//------------------------------------------------------------------------------
std::vector<int> TumblingDie::getRollHistory() const
{
    return vRolls;
}

//------------------------------------------------------------------------------
// rollDie(): uses push_back to add a value onto the vRolls Vector
//------------------------------------------------------------------------------
int TumblingDie::rollDie()
{
    int roll = rand() % this->sides + 1;
    value = roll;
    vRolls.push_back(roll);
    return roll;
}

//------------------------------------------------------------------------------
// getValue(): returns value of last roll
//------------------------------------------------------------------------------
int TumblingDie::getValue()
{
    this->value = rand() % this->sides + 1;
    vRolls.push_back(this->value);
    return this->value;
}