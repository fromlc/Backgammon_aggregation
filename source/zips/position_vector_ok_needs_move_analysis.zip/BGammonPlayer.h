//------------------------------------------------------------------------------
// CS 281-0798
// 
// BGammonPlayer class declaration file
//------------------------------------------------------------------------------
#pragma once
#ifndef BGAMMONPLAYER_H
#define BGAMMONPLAYER_H

#include <string>
#include <vector>

#include "TumblingDie.h"

//constexpr int PIECES_PLAYING = 15;
constexpr int PIECES_PLAYING = 3;

//------------------------------------------------------------------------------
// class BGammonPlayer : BGammonBoard aggregates two BGammonPlayer instances
//------------------------------------------------------------------------------
class BGammonPlayer
{
public:
//private:
    std::string name, color;
    // pair of dice
    TumblingDie die1, die2;
    // track point number for each piece
    std::vector<int> vPiecePositions;
    int pieceCount, numMoves, gamesWon;

public:
// constructors
    BGammonPlayer();
    BGammonPlayer(const std::string name, const std::string color);
// destructor
    ~BGammonPlayer();
 
// returns copy of pieces position vector - point number per piece
    std::vector<int> getPiecePositions();
// sets piece positions to 1 and resets piece count and move counter
    void resetPlayer();
// no params: returns # of pieces on board, including on the bar
// int param: returns # of pieces on specified point (1-20)
    int getPieceCount(int point = 0);
// get a new dice roll
    void rollDice(int& d1, int& d2);
// look at old dice roll
    void viewDice(int& d1, int& d2);
// moves the piece farthest along the board
    void makeBestMove(int movePoints, BGammonPlayer& opponent);
};

#endif  // BGAMMONPLAYER_H