/*******************************************************************************
* Backgammon Player App
* Kaillum Holmes
* CS 281-0798, Fall 2021
* Novemember 20, 2021
*
* returns the value of a roll using two 6-sided dice 
********************************************************************************
*/
#include "BackgammonPlayer.h"
#include <iostream>


//keep track of player position
void BackgammonPlayer::playerTurn()
{
	std::cout << "It is your turn" << '\n';

	void testDriver();


}

//play AI turn 
void AITurn()
{

}